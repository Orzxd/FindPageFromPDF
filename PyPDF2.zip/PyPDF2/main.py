from PyPDF2 import PdfReader
import re

reader = PdfReader("C:/Users/user/Desktop/Python Projects/PyPDF2/pdfs/w.pdf")
NumPages = len(reader.pages)

# define keyterms
StringList = ["read", "Engine"]

# extract text and do the search
for x in StringList:
    for i in range(0, NumPages):
        page = reader.pages[i]
        Text = page.extract_text()
        ResSearch = re.search(x, Text)
        if ResSearch is not None:
            #print(ResSearch)
            print("Keyword: " + x + " - " + "Page Number" + " " + str(i + 1))
